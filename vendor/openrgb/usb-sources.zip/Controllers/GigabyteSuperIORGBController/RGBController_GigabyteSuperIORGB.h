/*---------------------------------------------------------*\
| RGBController_GigabyteSuperIORGB.h                        |
|                                                           |
|   RGBController for Gigabyte Aorus Super IO motherboard   |
|                                                           |
|   Ryan Frankcombe (422gRdHuX5uk)              11 Sep 2022 |
|                                                           |
|   This file is part of the OpenRGB project                |
|   SPDX-License-Identifier: GPL-2.0-or-later               |
\*---------------------------------------------------------*/

#pragma once

#include "RGBController.h"
#include "GigabyteSuperIORGBController.h"

class RGBController_GigabyteSuperIORGB : public RGBController
{
public:
    RGBController_GigabyteSuperIORGB(GigabyteSuperIORGBController* controller_ptr);
    ~RGBController_GigabyteSuperIORGB();

    void        SetupZones();

    void        DeviceUpdateLEDs();
    void        DeviceUpdateZoneLEDs(int zone);
    void        DeviceUpdateSingleLED(int led);

    void        DeviceUpdateMode();

private:
    GigabyteSuperIORGBController*       controller;
};
