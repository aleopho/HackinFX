/*---------------------------------------------------------*\
| HPOmen30LControllerDetect.cpp                             |
|                                                           |
|   Detector for HP Omen 30L                                |
|                                                           |
|   This file is part of the OpenRGB project                |
|   SPDX-License-Identifier: GPL-2.0-or-later               |
\*---------------------------------------------------------*/

#include <hidapi.h>
#include "DetectionManager.h"
#include "HPOmen30LController.h"
#include "RGBController_HPOmen30L.h"

#define HP_OMEN_30L_VID 0x103C
#define HP_OMEN_30L_PID 0x84FD

DetectedControllers DetectHPOmen30LController(hid_device_info* info, const std::string&)
{
    DetectedControllers detected_controllers;
    hid_device*         dev;

    dev = hid_open_path(info->path);

    if(dev)
    {
        HPOmen30LController*     controller     = new HPOmen30LController(dev, info->path);
        RGBController_HPOmen30L* rgb_controller = new RGBController_HPOmen30L(controller);

        detected_controllers.push_back(rgb_controller);
    }

    return(detected_controllers);
}

REGISTER_HID_DETECTOR("HP Omen 30L", DetectHPOmen30LController, HP_OMEN_30L_VID, HP_OMEN_30L_PID);
